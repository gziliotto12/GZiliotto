--CieloVolo database developed and written by Giuliana Ziliotto
--Originally written May 2024 | Updated: ---
---------------------------------------------------------------
IF NOT EXISTS(SELECT * FROM sys.databases
	WHERE NAME = N'CieloVolo')
	CREATE DATABASE CieloVolo
GO

USE CieloVolo
GO

---------------------------------------------------------------
--Alter the path so the script can find the CSV files
--
DECLARE
	@data_path NVARCHAR(256);
SELECT @data_path = 'C:\Users\gzili\OneDrive\Desktop\CieloVolo SQL\';
--
--Delete existing tables

--FlightCrew isn't a table, but SQL reads it as such, so it deletes any weird errors by doing this.
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'FlightCrew'
       )
	DROP TABLE FlightCrew;

IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'FlightOrigin'
       )
	DROP TABLE FlightOrigin;
--
IF EXISTS(

	SELECT *
	FROM sys.tables
	WHERE NAME = N'FlightDestination'
       )
	DROP TABLE FlightDestination;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'EmployeeSchedule'
       )
	DROP TABLE EmployeeSchedule;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'Bag'
       )
	DROP TABLE Bag;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'Ticket'
       )
	DROP TABLE Ticket;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'Flight'
       )
	DROP TABLE Flight;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'Airport'
       )
	DROP TABLE Airport;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'Employee'
       )
	DROP TABLE Employee;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'Passenger'
       )
	DROP TABLE Passenger;

---------------------------------------------------------------
-- Create tables

CREATE TABLE Passenger
	(PassengerID	INT CONSTRAINT pk_PassengerID PRIMARY KEY,
	PassengerFirstName	NVARCHAR(254) CONSTRAINT nn_p_first NOT NULL,
	PassengerLastName	NVARCHAR(254),
	PassengerPhone	NVARCHAR(20) CONSTRAINT nn_p_phone NOT NULL,
	PassengerEmail	NVARCHAR(100) CONSTRAINT nn_p_email NOT NULL,
	PassengerAddress	NVARCHAR(200) CONSTRAINT nn_p_address NOT NULL,
	PassengerCity	NVARCHAR(254) CONSTRAINT nn_p_city NOT NULL,
	PassengerState	NVARCHAR(3) CONSTRAINT nn_p_state NOT NULL,
	PassengerZip	NVARCHAR(15) CONSTRAINT nn_p_zip NOT NULL
	);
--
CREATE TABLE Employee
	(EmployeeID NVARCHAR(10) CONSTRAINT pk_EmployeeID PRIMARY KEY,
	EmployeeTitle	NVARCHAR(100) CONSTRAINT nn_e_title NOT NULL,
	EmployeeFirstName	NVARCHAR(254) CONSTRAINT nn_e_first NOT NULL,
	EmployeeLastName	NVARCHAR(254),
	EmployeePhone	NVARCHAR(15) CONSTRAINT nn_e_phone NOT NULL,
	EmployeeEmail	NVARCHAR(100) CONSTRAINT nn_e_email NOT NULL,
	EmployeeAddress	NVARCHAR(200) CONSTRAINT nn_e_address NOT NULL,
	EmployeeCity	NVARCHAR(254) CONSTRAINT nn_e_city NOT NULL,
	EmployeeState	NVARCHAR(3) CONSTRAINT nn_e_state NOT NULL,
	EmployeeZip	NVARCHAR(15) CONSTRAINT nn_e_zip NOT NULL
	);
--
CREATE TABLE Airport
	(AirportID	NVARCHAR(3) CONSTRAINT pk_AirportID PRIMARY KEY,
	AirportName	NVARCHAR(200) CONSTRAINT nn_a_name NOT NULL,
	AirportCity	NVARCHAR(250) CONSTRAINT nn_a_city NOT NULL,
	AirportState NVARCHAR(3) CONSTRAINT nn_a_state NOT NULL
	);
--
CREATE TABLE Flight
	(FlightID INT CONSTRAINT pk_FlightID PRIMARY KEY,
	FlightDeparture	TIME CONSTRAINT nn_f_depart NOT NULL,
	FlightArrival	TIME CONSTRAINT nn_f_arrival NOT NULL,
	FlightAircraft	NVARCHAR(100) CONSTRAINT nn_f_aircraft NOT NULL,
	FlightAircraftSerial	NVARCHAR(100) CONSTRAINT nn_f_aircraftserial NOT NULL
	);
--
CREATE TABLE Ticket
	(TicketID INT CONSTRAINT pk_TicketID PRIMARY KEY,
	PassengerID INT FOREIGN KEY REFERENCES Passenger(PassengerID),
	FlightID INT FOREIGN KEY REFERENCES Flight(FlightID) NOT NULL,
	TicketPrice	MONEY CONSTRAINT nn_t_price NOT NULL,
	TicketSeat	NVARCHAR(3) CONSTRAINT nn_t_seat NOT NULL,
	TicketGate	NVARCHAR(3) CONSTRAINT nn_t_aircraft NOT NULL,
	TicketDate	DATE CONSTRAINT nn_t_date NOT NULL
	);
--
CREATE TABLE Bag
	(BagID INT CONSTRAINT pk_BagID PRIMARY KEY,
	TicketID INT FOREIGN KEY REFERENCES Ticket(TicketID) NOT NULL,
	BagWeight	INT CONSTRAINT nn_b_weight NOT NULL,
	BagWidth INT CONSTRAINT nn_b_width NOT NULL,
	BegHeight INT CONSTRAINT nn_b_height NOT NULL,
	BagLength INT CONSTRAINT nn_b_length NOT NULL
	);
--
CREATE TABLE EmployeeSchedule
	(EmployeeScheduleID INT CONSTRAINT pk_EmployeeScheduleID PRIMARY KEY,
	FlightID INT FOREIGN KEY REFERENCES Flight(FlightID) NOT NULL,
	EmployeeID NVARCHAR(10) FOREIGN KEY REFERENCES Employee(EmployeeID) NOT NULL
	);
--
CREATE TABLE FlightDestination
	(FlightDestinationID INT CONSTRAINT pk_FlightDestinationID PRIMARY KEY,
	FlightID INT FOREIGN KEY REFERENCES Flight(FlightID) NOT NULL,
	AirportID NVARCHAR(3) FOREIGN KEY REFERENCES Airport(AirportID) NOT NULL
	);
--
CREATE TABLE FlightOrigin
	(FlightOriginID INT CONSTRAINT pk_FlightOriginID PRIMARY KEY,
	FlightID INT FOREIGN KEY REFERENCES Flight(FlightID) NOT NULL,
	AirportID NVARCHAR(3) FOREIGN KEY REFERENCES Airport(AirportID) NOT NULL
	);

---------------------------------------------------------------
--Bulk Insert Data

EXECUTE (N'BULK INSERT Passenger FROM ''' + @data_path + N'PASSENGER.csv''
WITH (
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
EXECUTE (N'BULK INSERT Employee FROM ''' + @data_path + N'EMPLOYEE.csv''
WITH (
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
EXECUTE (N'BULK INSERT Airport FROM ''' + @data_path + N'AIRPORT.csv''
WITH (
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
EXECUTE (N'BULK INSERT Flight FROM ''' + @data_path + N'FLIGHT.csv''
WITH (
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
EXECUTE (N'BULK INSERT Ticket FROM ''' + @data_path + N'TICKET.csv''
WITH (
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
EXECUTE (N'BULK INSERT Bag FROM ''' + @data_path + N'BAG.csv''
WITH (
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
EXECUTE (N'BULK INSERT EmployeeSchedule FROM ''' + @data_path + N'EMPLOYEESCHEDULE.csv''
WITH (
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
EXECUTE (N'BULK INSERT FlightDestination FROM ''' + @data_path + N'FLIGHTDESTINATION.csv''
WITH (
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
EXECUTE (N'BULK INSERT FlightOrigin FROM ''' + @data_path + N'FLIGHTORIGIN.csv''
WITH (
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
GO

---------------------------------------------------------------
--VIEW:
	--Flight Attendants, Pilots, and Co Pilots assigned for each flight:
	--This will allow easy view of crew so that each flight is appropriately staffed.
	--The only crew necessary on the actual flight are the Pilot, Co-Pilot, and Flight Attendants; that is why only these are specified in the view.

--Delete existing view
IF EXISTS(
	SELECT * 
	FROM sys.views 
	WHERE object_id = OBJECT_ID(N'[dbo].[FlightCrew]'))
    DROP VIEW [dbo].[FlightCrew]
;
GO

--Create view
CREATE VIEW FlightCrew AS
SELECT f.FlightID
, e.EmployeeID
, e.EmployeeFirstName
, e.EmployeeLastName
, e.EmployeeTitle
FROM Flight f
	JOIN EmployeeSchedule es 
		ON f.FlightID = es.FlightID
	JOIN Employee e 
		ON es.EmployeeID = e.EmployeeID
WHERE e.EmployeeTitle IN ('Flight Attendant', 'Pilot', 'Co Pilot')
;
GO

---------------------------------------------------------------
--USER DEFINED FUNCTION:
	--This function works to check whether there is a scheduling conflict for a newly added assignment in the Employee Schedule table based on FlightDeparture time.
	--The point of this is to make sure that employees are not double scheduled for flights.

--Delete existing function
IF OBJECT_ID('CheckScheduleConflict', 'FN') IS NOT NULL
    DROP FUNCTION CheckScheduleConflict
;
GO

--Create function
CREATE FUNCTION CheckScheduleConflict(@EmployeeID NVARCHAR(10), @NewFlightID INT)
RETURNS BIT
BEGIN
    DECLARE @ConflictCount INT;

    SELECT @ConflictCount = COUNT(*)
    FROM Flight f
    JOIN EmployeeSchedule es ON f.FlightID = es.FlightID
    WHERE es.EmployeeID = @EmployeeID AND f.FlightID <> @NewFlightID
          AND EXISTS (
              SELECT 1
              FROM Flight f2
              WHERE f2.FlightID = @NewFlightID AND f.FlightDeparture = f2.FlightDeparture
          );

    RETURN CASE WHEN @ConflictCount > 0 THEN 1 ELSE 0 END;
END;
GO

---------------------------------------------------------------
--PROCEDURE:
	--This procedure is meant to allow the addition of an employee to the EmployeeSchedule for a given flight.
	--If the FlightCrew view shows that there aren't enough Flight Attendents, Co Pilots, or Pilots for a given flight, an employee can be assigned to the flight
	--if it doesn't conflict with their current departure time.

--Delete existing procedure
IF OBJECT_ID('AssignFlightToEmployee', 'P') IS NOT NULL
    DROP PROCEDURE AssignFlightToEmployee
;
GO

--Create procedure
CREATE PROCEDURE AssignFlightToEmployee
    @EmployeeID NVARCHAR(10),
    @FlightID INT
AS
BEGIN
    DECLARE @EmployeeScheduleID INT;
    DECLARE @Exists BIT;

--Generate a unique EmployeeScheduleID
    SELECT @EmployeeScheduleID = COALESCE(MAX(EmployeeScheduleID), 0) + 1 FROM EmployeeSchedule;

--Check for existing identical assignment to prevent duplicates in FlightCrew
    SELECT @Exists = CASE WHEN EXISTS (
        SELECT 1
        FROM EmployeeSchedule
        WHERE EmployeeID = @EmployeeID AND FlightID = @FlightID
    ) THEN 1 ELSE 0 END;

    IF @Exists = 1
    BEGIN
        PRINT 'Duplicate entry. Assignment not added.';
        RETURN;
    END

    IF (SELECT dbo.CheckScheduleConflict(@EmployeeID, @FlightID)) = 1
    BEGIN
        RAISERROR('Scheduling conflict. Cannot assign this flight.', 16, 1);
    END
    ELSE
    BEGIN
        -- Assign the flight using the new EmployeeScheduleID
        INSERT INTO EmployeeSchedule(EmployeeScheduleID, EmployeeID, FlightID)
        VALUES (@EmployeeScheduleID, @EmployeeID, @FlightID);
        
        PRINT 'Flight successfully assigned to employee with new EmployeeScheduleID: ' + CAST(@EmployeeScheduleID AS NVARCHAR(10));
    END
END;
GO