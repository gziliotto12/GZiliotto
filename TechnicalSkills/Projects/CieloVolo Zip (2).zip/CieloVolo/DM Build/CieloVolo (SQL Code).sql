IF NOT EXISTS(SELECT * FROM sys.databases WHERE NAME = N'FlightsDM')
    CREATE DATABASE FlightsDM;
GO

USE FlightsDM;

IF EXISTS(SELECT * FROM sys.tables WHERE name = N'FactTicketSales')
    DROP TABLE FactTicketSales;

IF EXISTS(SELECT * FROM sys.tables WHERE name = N'DimPassenger')
    DROP TABLE DimPassenger;

IF EXISTS(SELECT * FROM sys.tables WHERE name = N'DimFlightOrigin')
    DROP TABLE DimFlightOrigin;

IF EXISTS(SELECT * FROM sys.tables WHERE name = N'DimFlightDestination')
    DROP TABLE DimFlightDestination;

IF EXISTS(SELECT * FROM sys.tables WHERE name = N'DimEmployee')
    DROP TABLE DimEmployee;

IF EXISTS(SELECT * FROM sys.tables WHERE name = N'DimDate')
    DROP TABLE DimDate;


CREATE TABLE DimPassenger (
    Passenger_SK INT IDENTITY(1,1) PRIMARY KEY,  -- Surrogate Key
    Passenger_BK INT,  -- Business Key
    PassengerFirstName NVARCHAR(50),
    PassengerLastName NVARCHAR(50),
    PassengerCity NVARCHAR(50),
    PassengerState NVARCHAR(50),
    PassengerZip NVARCHAR(10),
	PassengerRegion NVARCHAR(30),
	PassengerFirstandLast NVARCHAR(50),
);

CREATE TABLE DimFlightOrigin (
    FlightOrigin_SK INT IDENTITY(1,1) PRIMARY KEY,  -- Surrogate Key
    FlightOrigin_BK INT,  -- Business Key
    AirportID NVARCHAR(10),
    AirportName NVARCHAR(100),
    AirportCity NVARCHAR(100),
    AirportState NVARCHAR(50),
	AirportRegion NVARCHAR(30)
);

CREATE TABLE DimFlightDestination (
    FlightDestination_SK INT IDENTITY(1,1) PRIMARY KEY,  -- Surrogate Key
    FlightDestination_BK INT,  -- Business Key
    AirportID NVARCHAR(10),
    AirportName NVARCHAR(100),
    AirportCity NVARCHAR(100),
    AirportState NVARCHAR(50),
	AirportRegion NVARCHAR(30)
);

CREATE TABLE DimEmployee (
    EmployeeID_SK INT IDENTITY(1,1) PRIMARY KEY,  -- Surrogate Key
    EmployeeID_BK INT,  -- Business Key
    EmployeeTitle NVARCHAR(50),
    EmployeeFirst NVARCHAR(50),
    EmployeeLast NVARCHAR(50),
    EmployeeCity NVARCHAR(50),
    EmployeeState NVARCHAR(50),
    EmployeeZip NVARCHAR(10),
	EmployeeRegion NVARCHAR(30),
	EmployeeFirstandLast NVARCHAR(50)
);

CREATE TABLE DimDate (
	Date_SK				INT CONSTRAINT pk_date_key PRIMARY KEY, 
	Date				DATE,
	FullDate			NCHAR(10), -- Date in MM-DD-YYYY format
	DayOfMonth			INT, -- Day number of Month
	DayName				NVARCHAR(9), -- Monday, Tuesday, etc. 
	DayOfWeek			INT, -- First Day Sunday=1 and Saturday=7
	DayOfWeekInMonth	INT, -- 1st Monday or 2nd Monday in Month
	DayOfWeekInYear		INT,
	DayOfQuarter		INT,
	DayOfYear			INT,
	WeekOfMonth			INT,-- Week Number of Month 
	WeekOfQuarter		INT, -- Week Number of the Quarter
	WeekOfYear			INT,-- Week Number of the Year
	Month				INT, -- Number of the Month 1 to 12.
	MonthName			NVARCHAR(9), -- January, February etc.
	MonthOfQuarter		INT, -- Month Number belongs to Quarter
	Quarter				NCHAR(2),
	QuarterName			NCHAR(2), -- First,Second..
	Year				INT, -- Year value of Date stored in Row
	CYearName			NCHAR(7), -- CY 2017,CY 2018
	FYearName			NCHAR(7), -- CY 2017,CY 2018
	MonthYear			NCHAR(10), -- Jan-2018,Feb-2018
	MMYYYY				INT,
	FirstDayOfMonth		DATE,
	LastDayOfMonth		DATE,
	FirstDayOfQuarter	DATE,
	LastDayOfQuarter	DATE,
	FirstDayOfYear		DATE,
	LastDayOfYear		DATE,
	IsWeekday			BIT, -- 0=Weekend ,1=Weekday,
	IsWeekdayName		NVARCHAR(55), -- Weekend, Weekday
	IsHoliday			BIT, -- 1=National Holiday, 0-Not a National 
);


CREATE TABLE FactTicketSales (
    TicketID INT, 
    PassengerID_SK INT,
    FlightOriginID_SK INT, 
    FlightDestinationID_SK INT, 
    EmployeeID_SK INT,  
    Date_SK INT, 
    TicketPrice DECIMAL(10, 2), 
    
    FOREIGN KEY (PassengerID_SK) REFERENCES DimPassenger(Passenger_SK),
    FOREIGN KEY (FlightOriginID_SK) REFERENCES DimFlightOrigin(FlightOrigin_SK),
    FOREIGN KEY (FlightDestinationID_SK) REFERENCES DimFlightDestination(FlightDestination_SK),
    FOREIGN KEY (EmployeeID_SK) REFERENCES DimEmployee(EmployeeID_SK),
    FOREIGN KEY (Date_SK) REFERENCES DimDate(Date_SK),

    PRIMARY KEY (TicketID, PassengerID_SK, FlightOriginID_SK, FlightDestinationID_SK, EmployeeID_SK, Date_SK)
);
