--INFO 3140 || CIELOVOLO DATABASE PROJECT || GIULIANA ZILIOTTO--


--1Bag Information

--QUERY EXPLANATION: Bag information including the destination airport, whether the bag is overweight (weight > 50), bag measurements, full passenger name, and passenger phone number.
----BUSINESS QUESTION: How can we efficiently track and manage baggage for passengers traveling to their final airport destinations, including collecting data on bags' measurements and identifying overweight bags necessitating overweight charges?

SELECT BAG.BagID
	, AIRPORT.AirportName AS DestinationAirport
	, IIF(BAG.BagWeight > 50, "Overweight", "Not Overweight") AS WeightStatus
	, BAG.BagWidth, BAG.BagLength, BAG.BagHeight
	, PASSENGER.PassengerFirstName & " " & PASSENGER.PassengerLastName AS FullName
	, PASSENGER.PassengerPhone AS Phone
FROM ((PASSENGER 
	INNER JOIN (TICKET 
	INNER JOIN BAG 
		ON TICKET.TicketID = BAG.TicketID) 
		ON PASSENGER.PassengerID = TICKET.PassengerID) 
	INNER JOIN (FLIGHT 
	INNER JOIN FLIGHT_DESTINATION 
		ON FLIGHT.FlightID = FLIGHT_DESTINATION.FlightID) 
		ON TICKET.FlightID = FLIGHT.FlightID) 
	INNER JOIN AIRPORT 
		ON FLIGHT_DESTINATION.AirportID = AIRPORT.AirportID
WHERE BAG.BagWeight IS NOT NULL;


--2Passenger Contact & Number of Flights

--QUERY EXPLANATION: All passengers and their phone number, email, full address, and the number of flights they've had from greatest to least.
----BUSINESS QUESTION: How many times have our clients flown with us, with insights into their flight frequency and contact details?

SELECT PASSENGER.PassengerFirstName & " " & PASSENGER.PassengerLastName AS FullName
	, PASSENGER.PassengerPhone AS Phone
	, PASSENGER.PassengerEmail AS Email
	, PASSENGER.PassengerAddress & ", " & PASSENGER.PassengerCity & ", " & PASSENGER.PassengerState AS FullAddress
	, COUNT(FLIGHT.FlightID) AS NumberofFlights
FROM (PASSENGER 
	LEFT OUTER JOIN TICKET 
		ON PASSENGER.PassengerID = TICKET.PassengerID) 
	LEFT OUTER JOIN FLIGHT 
		ON TICKET.FlightID = FLIGHT.FlightID
GROUP BY PASSENGER.PassengerID
	, PASSENGER.PassengerFirstName
	, PASSENGER.PassengerLastName
	, PASSENGER.PassengerPhone
	, PASSENGER.PassengerEmail
	, PASSENGER.PassengerAddress
	, PASSENGER.PassengerCity
	, PASSENGER.PassengerState
ORDER BY COUNT(FLIGHT.FlightID) DESC
	, PASSENGER.PassengerLastName
	, PASSENGER.PassengerFirstName;


--3Total Profits & Flights By Destination City

--QUERY EXPLANATION: Number of flights and profit by city and airport in descending order by total profit.
----BUSINESS QUESTION: What are the flight counts and total profit per city and airport, organized in descending order, to identify the most profitable and popular locations in terms of destination?

SELECT AIRPORT.AirportCity AS City
	, AIRPORT.AirportName AS Airport
	, COUNT(FLIGHT.FlightID) AS NumberOfFlights
	, SUM(TICKET.TicketPrice) AS TotalProfit
FROM ((FLIGHT 
	INNER JOIN FLIGHT_DESTINATION 
		ON FLIGHT.FlightID = FLIGHT_DESTINATION.FlightID) 
	INNER JOIN TICKET 
		ON FLIGHT.FlightID = TICKET.FlightID) 
	INNER JOIN AIRPORT 
		ON FLIGHT_DESTINATION.AirportID = AIRPORT.AirportID
GROUP BY AIRPORT.AirportName
	, AIRPORT.AirportCity
ORDER BY SUM(TICKET.TicketPrice) DESC;


--4Total Profits & Flights By Destination State

--QUERY EXPLANATION: Number of flights by destination state in descending order by total profit.
----BUSINESS QUESTION: What are the flight counts and total profits per state, organized in descending order, to identify the most profitable and popular locations in terms of destination?

SELECT AIRPORT.AirportState AS State
	, COUNT(FLIGHT.FlightID) AS NumberOfFlights
	, SUM(TICKET.TicketPrice) AS TotalProfit
FROM ((FLIGHT 
	INNER JOIN FLIGHT_DESTINATION 
		ON FLIGHT.FlightID = FLIGHT_DESTINATION.FlightID) 
	INNER JOIN TICKET 
		ON FLIGHT.FlightID = TICKET.FlightID) 
	INNER JOIN AIRPORT 
		ON FLIGHT_DESTINATION.AirportID = AIRPORT.AirportID
GROUP BY AIRPORT.AirportState
ORDER BY SUM(TICKET.TicketPrice) DESC;


--5Total Profits & Flights By Month

--QUERY EXPLANATION: Number of flights and total profit by month in descending order by the most recent month.
----BUSINESS QUESTION: What is the total profit and distribution of flight frequency by month, ranked in descending order with the most recent month at the top, to identify trends and seasonal patterns in our destination offerings?"

SELECT FORMAT(TICKET.TicketDate, "yyyy-mm") AS MonthYear
	, COUNT(TICKET.FlightID) AS NumberOfFlights
	, SUM(TICKET.TicketPrice) AS TotalMonthProfit
FROM TICKET
GROUP BY FORMAT(TICKET.TicketDate, "yyyy-mm")
ORDER BY FORMAT(TICKET.TicketDate, "yyyy-mm") DESC;


--6Total Flights By Origin City

--QUERY EXPLANATION: Number of flights by origin city and airport in descending order by flight count.
----BUSINESS QUESTION: What are the flight counts categorized by origin city and airport, organized in descending order by flight count, to pinpoint the busiest departure points in our operations?

SELECT AIRPORT.AirportCity
	, AIRPORT.AirportName
	, COUNT(FLIGHT_ORIGIN.FlightID) AS NumberOfFlights
FROM (FLIGHT 
	INNER JOIN FLIGHT_ORIGIN 
		ON FLIGHT.FlightID = FLIGHT_ORIGIN.FlightID) 
	INNER JOIN AIRPORT 
		ON FLIGHT_ORIGIN.AirportID = AIRPORT.AirportID
GROUP BY AIRPORT.AirportCity
	, AIRPORT.AirportName
ORDER BY COUNT(FLIGHT_ORIGIN.FlightID) DESC;


--7Total Flights By Origin State

--QUERY EXPLANATION: Number of flights by origin state in descending order by flight count.
----BUSINESS QUESTION: What is the breakdown of flight frequencies based on origin state, ranked in descending order by flight count, to understand the geographical distribution of our flight departures?

SELECT AIRPORT.AirportState
	, COUNT(FLIGHT.FlightID) AS NumberOfFlights
FROM (FLIGHT 
	INNER JOIN FLIGHT_ORIGIN 
		ON FLIGHT.FlightID = FLIGHT_ORIGIN.FlightID) 
	INNER JOIN AIRPORT 
		ON FLIGHT_ORIGIN.AirportID = AIRPORT.AirportID
GROUP BY AIRPORT.AirportState
ORDER BY COUNT(FLIGHT.FlightID) DESC;


--8Tickets Over Avg Price, Price, & Passenger Contact

--QUERY EXPLANATION: Tickets that cost more than average ticket price (utilizes subquery in WHERE clause to find this), ticket id, passenger info, and ticket price.
----BUSINESS QUESTION: What is the inventory of tickets priced above the average ticket price, including ticket ID, passenger information, and respective ticket prices, to identify potential high-value customers and analyze pricing strategies?

SELECT TICKET.TicketID
    , PASSENGER.PassengerFirstName & " " & PASSENGER.PassengerLastName AS FullName
    , PASSENGER.PassengerPhone AS Phone
    , TICKET.TicketPrice
FROM PASSENGER
	INNER JOIN TICKET
		ON PASSENGER.PassengerID = TICKET.PassengerID
WHERE TICKET.TicketPrice > (
	SELECT AVG(TicketPrice)
	FROM TICKET);